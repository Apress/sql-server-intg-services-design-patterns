use master
go

If Not Exists(Select name
              From sys.databases
	      Where name='StagingDB')
 begin
  print 'Creating StagingDB database'
  Create Database StagingDB
  print 'StagingDB database created'
 end
Else
 print 'StagingDb database already exists.'
