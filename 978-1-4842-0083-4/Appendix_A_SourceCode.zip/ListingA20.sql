/* Add "0" rows */
If Not Exists(Select ApplicationID
              From cfg.Applications
                      Where ApplicationID = 0)
 begin
  print 'Adding 0 row for cfg.Applications'
  Set Identity_Insert cfg.Applications ON
  Insert Into cfg.Applications
  (ApplicationID
  ,ApplicationName)
  Values
  (0
  ,'SSIS Framework')
  Set Identity_Insert cfg.Applications OFF
  print '0 row for cfg.Applications added'
 end
Else
 print '0 row already exists for cfg.Applications'
print ''

If Not Exists(Select PackageID
              From cfg.Packages
                      Where PackageID = 0)
 begin
  print 'Adding 0 row for cfg.Packages'
  Set Identity_Insert cfg.Packages ON
  Insert Into cfg.Packages
  (PackageID
  ,PackageFolder
  ,PackageName)
  Values
  (0
  ,'\'
  ,'parent.dtsx')
  Set Identity_Insert cfg.Packages OFF
  print '0 row for cfg.Packages added'
 end
Else
 print '0 row already exists for cfg.Packages'
print ''

If Not Exists(Select AppPackageID
              From cfg.AppPackages
                      Where AppPackageID = 0)
 begin
  print 'Adding 0 row for cfg.Packages'
  Set Identity_Insert cfg.AppPackages ON
  Insert Into cfg.AppPackages
  (AppPackageID
  ,ApplicationID
  ,PackageID
  ,ExecutionOrder)
  Values
  (0
  ,0
  ,0
  ,10)
  Set Identity_Insert cfg.AppPackages OFF
  print '0 row for cfg.AppPackages added'
 end
Else
 print '0 row already exists for cfg.AppPackages'
print ''

If Not Exists(Select AppInstanceID
              From [log].SSISAppInstance
                      Where AppInstanceID = 0)
 begin
  print 'Adding 0 row for cfg.Packages'
  Set Identity_Insert [log].SSISAppInstance ON
  Insert Into [log].SSISAppInstance
  (AppInstanceID
  ,ApplicationID
  ,StartDateTime
  ,EndDateTime
  ,[Status])
  Values
  (0
  ,0
  ,'1/1/1900'
  ,'1/1/1900'
  ,'Unknown')
  Set Identity_Insert [log].SSISAppInstance OFF
  print '0 row for log.SSISAppInstance added'
 end
Else
 print '0 row already exists for log.SSISAppInstance'
print ''


If Not Exists(Select PkgInstanceID
              From [log].SSISPkgInstance
                      Where PkgInstanceID = 0)
 begin
  print 'Adding 0 row for cfg.Packages'
  Set Identity_Insert [log].SSISPkgInstance ON
  Insert Into [log].SSISPkgInstance
  (PkgInstanceID
  ,AppInstanceID
  ,AppPackageID
  ,StartDateTime
  ,EndDateTime
  ,[Status])
  Values
  (0
  ,0
  ,0
  ,'1/1/1900'
  ,'1/1/1900'
  ,'Unknown')
  Set Identity_Insert [log].SSISPkgInstance OFF  print '0 row for log.SSISPkgInstance added'
 end
Else
 print '0 row already exists for log.SSISPkgInstance'
print ''
