/* rpt.ReturnPkgInstanceHeader stored procedure */
If Exists(Select s.name + '.' + p.name
          From sys.procedures p
          Join sys.schemas s
            On s.schema_id = p.schema_id
          Where s.name = 'rpt'
            And p.name = 'ReturnPkgInstanceHeader')
 begin
  print 'Dropping rpt.ReturnPkgInstanceHeader stored procedure'
  Drop Procedure rpt.ReturnPkgInstanceHeader
  print 'Rpt.ReturnPkgInstanceHeader stored procedure dropped'
 end
print 'Creating rpt.ReturnPkgInstanceHeader stored procedure'
go

Create Procedure rpt.ReturnPkgInstanceHeader
 @AppInstanceID int
As

             SELECT a.ApplicationName
                      ,p.PackageFolder + p.PackageName As PackagePath
                      ,cp.StartDateTime
                      ,DateDiff(ss,cp.StartDateTime,Coalesce(cp.EndDateTime,GetDate())) As RunSeconds
                      ,cp.Status
                      ,ai.AppInstanceID
                      ,cp.PkgInstanceID
                      ,p.PackageID
                      ,p.PackageName
                FROM log.SSISPkgInstance cp
                Join cfg.AppPackages ap 
                    on ap.PackageID = cp.AppPackageID
               Join cfg.Packages p 
                    on p.PackageID = ap.AppPackageID
               Join log.SSISAppInstance ai
                    on ai.AppInstanceID = cp.AppInstanceID
               Join cfg.Applications a
                    on a.ApplicationID = ap.ApplicationID
              WHERE ai.AppInstanceID = Coalesce(@AppInstanceID,ai.AppInstanceID)
               And a.ApplicationID > 0
              Order By cp.PkgInstanceID desc
go
print 'Rpt.ReturnPkgInstanceHeader stored procedure created.'
print ''
