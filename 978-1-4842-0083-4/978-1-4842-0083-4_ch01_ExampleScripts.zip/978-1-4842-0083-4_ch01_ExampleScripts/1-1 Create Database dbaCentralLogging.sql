-- Listing 1-1. Example of T-SQL Code to Create a SQL Server Database

USE [master];
GO

CREATE DATABASE [dbaCentralLogging] 
ON PRIMARY
(
      NAME = N'dbaCentralLogging'
    , FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\dbaCentralLogging.mdf'
    , SIZE = 1024MB 
    , MAXSIZE = UNLIMITED
    , FILEGROWTH = 1024MB
)
LOG ON
(
      NAME = N'dbaCentralLogging_log'
    , FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\dbaCentralLogging_log.ldf'
    , SIZE = 256MB
    , MAXSIZE = UNLIMITED
    , FILEGROWTH = 256MB
);
GO

WAITFOR DELAY '00:00:05';