-- Listing 1-2. Example of T-SQL Code to Create a Table for Monitoring SQL Server Instances

USE dbaCentralLogging;
GO

CREATE TABLE dbo.dba_monitor_SQLServerInstances
(
      SQLServerInstance   NVARCHAR(128)
    , LastMonitored       SMALLDATETIME     NULL

    CONSTRAINT PK_dba_monitor_SQLServerInstances
    PRIMARY KEY CLUSTERED( SQLServerInstance )
);
