-- Listing 1-8. T-SQL Code to Create the dba_monitor_unusedIndexes Table

USE dbaCentralLogging;
GO

CREATE TABLE dbo.dba_monitor_unusedIndexes
(
     log_id                    INT IDENTITY(1,1)
    ,captureDate               DATETIME
    ,serverName                NVARCHAR(128)
    ,schemaName                SYSNAME
    ,databaseName              SYSNAME
    ,tableName                 SYSNAME
    ,indexName                 SYSNAME
    ,indexType                 NVARCHAR(60)
    ,isFiltered                BIT
    ,isPartitioned             BIT
    ,numberOfRows              BIGINT
    ,userSeeksSinceReboot      BIGINT
    ,userScansSinceReboot      BIGINT
    ,userLookupsSinceReboot    BIGINT
    ,userUpdatesSinceReboot    BIGINT
    ,indexSizeInMB             BIGINT
    ,lastReboot                DATETIME

    CONSTRAINT PK_dba_monitor_unusedIndexes
        PRIMARY KEY NONCLUSTERED(log_id)
);

CREATE CLUSTERED INDEX CIX_dba_monitor_unusedIndexes
    ON dbo.dba_monitor_unusedIndexes(captureDate);
