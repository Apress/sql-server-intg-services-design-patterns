-- Listing 1-5. Example of T-SQL to Retrieve Current Data andLog File Sizes for All Databases on the Server

SELECT GETDATE() AS [captureDate]
    , @@SERVERNAME AS [serverName]
    , instance_name AS [databaseName]
    , SUM(
        CASE
        WHEN counter_name = 'Data File(s) Size (KB)'
        THEN cntr_value
        END
    ) AS 'dataSizeInKB'
    , SUM(
        CASE
        WHEN counter_name = 'Log File(s) Size (KB)'
        THEN cntr_value
        END
    ) AS 'logSizeInKB'
FROM sys.dm_os_performance_counters
WHERE counter_name IN ('Data File(s) Size (KB)'
    ,'Log File(s) Size (KB)')
/* optional: remove _Total to avoid accidentally
double-counting in queries */
    AND instance_name <> '_Total'
GROUP BY instance_name;
